package com.example.myapplication

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val button: Button = findViewById(R.id.button)
        val text: TextView = findViewById(R.id.textView2)
        val editText: EditText = findViewById(R.id.editText)

        var count: Int = 1

        button.setOnClickListener{
            val intent = Intent(this@MainActivity, SecondActivity::class.java)
            intent.putExtra("fio$count", editText.text.toString())
            if (count == 3){
                startActivity(intent)
            }
            text.text = "Вы ввели $count ФИО!"
            count++
        }
    }
}