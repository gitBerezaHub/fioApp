package com.example.myapplication

import android.app.Activity
import android.os.Bundle

class SecondActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_second)

        val fio1: String? = intent.extras?.getString("fio1")
        val fio2: String? = intent.extras?.getString("fio2")
        val fio3: String? = intent.extras?.getString("fio3")



    }

    public fun splitName(fio: String): String {
        val str: String[2]
        return str
    }
}